# REV02 Sun 03 Oct 2021 17:01:05 WIB
# START Fri 26 Mar 2021 23:46:34 WIB

RESULT="WEEK05-MEMORY.txt"
DIR="memory/"

# Delete Old File
rm -f ../$RESULT

# Go Inside
cd $DIR

echo "clean all"
make clean

echo "compile all"
make

echo "ZCZC pwd  $(pwd)"            >  ../../$RESULT
echo "ZCZC date $(date)"           >> ../../$RESULT
echo "ZCZC memory1"                >> ../../$RESULT
./mymemory1                        >> ../../$RESULT
sleep 1
echo "ZCZC memory2"                >> ../../$RESULT
./mymemory2                        >> ../../$RESULT
echo "ZCZC lsal $(ls -al)"         >> ../../$RESULT
echo "ZCZC clean $(make clean)"    >> ../../$RESULT
make clean
echo "READ $RESULT"

exit
exit

