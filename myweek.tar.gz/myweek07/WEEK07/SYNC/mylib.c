/*
 * Copyright (C) 2021-2021 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This program is free script/software. This program is distributed in the 
 * hope that it will be useful, but WITHOUT ANY WARRANTY; without even the 
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# INFO: mylib.c
 * REV03 Fri 29 Oct 2021 13:20:17 WIB
 * REV02 Thu 28 Oct 2021 17:12:31 WIB
 * REV01 Thu 21 Oct 2021 10:51:49 WIB
 * START Sat 10 Apr 2021 16:13:36 WIB
 */

#include "mylib.h"

Buf    bufHostName[BUFSIZE1];
String getHost(void) {
    if (gethostname(bufHostName,BUFSIZE1)) strcpy(bufHostName,"HostNameError");
    return bufHostName;
}

String getGroupName(void) {
    return (getgrgid(getgid()))->gr_name;
}

String getUserName(void) {
    String userStr=getlogin();
    if   (userStr==NULL) userStr="UserNameError";
    return userStr;
}

Buf    bufEpoch[BUFSIZE1];
String getEpoch(void) {
    FILE* filePtr = popen(GETDATE, "r");
    UL    tmpLong = atol(fgets(bufEpoch, BUFSIZE1, filePtr));
    pclose (filePtr);
    sprintf(bufEpoch, "%16.16lX", tmpLong);
    return (bufEpoch+8);
}

Buf    bufSTAMP[BUFSIZE3];
String getStamp(void) {
    Buf    tmpSTR[BUFSIZE1];
    strcpy(tmpSTR,"XXXXXXXX");
    String tmpEpoch=getEpoch();
    if (!strcmp(getHost(), getUserName())) {
        strcpy(tmpSTR,getUserName());
        strcat(tmpSTR,tmpEpoch);
        Buf  tmpCMD[BUFSIZE2];
        sprintf(tmpCMD, DOSHASUM, tmpSTR);
        FILE* filePtr = popen(tmpCMD, "r");
        fgets(tmpSTR, RESULT+1, filePtr);
        tmpSTR[RESULT]=0;
        pclose(filePtr);
    }
    bufSTAMP[0]=0;
    strcpy(bufSTAMP,tmpEpoch);
    strcat(bufSTAMP," ");
    strcat(bufSTAMP,tmpSTR);
    return bufSTAMP;
}

void error(int errornum, String message) {
    fprintf(stderr, "ZCZC ERROR %s\n", message);
    exit(errornum);
}

void report1(String message) {
    String filename=FILE1;
    report(filename, message);
}

void report2(String message) {
    String filename=FILE2;
    report(filename, message);
}

void report(String filename, String message) {
    static int  fd;
    static bool pertamax=true;
    if (pertamax) {
      pertamax=false;
      fd = open(filename, O_CREAT | O_RDWR | O_TRUNC, CHMOD1);
      if (fd<0) error(1,"OPEN fd FAILED ======");
      printf(     "ZCZC OPEN %s SUCCESS\n", filename);
      dprintf(fd, "ZCZC OPEN %s SUCCESS\n", filename);
    }
    printf (   "%s", message);
    dprintf(fd,"%s", message);
    fflush(NULL);
}

