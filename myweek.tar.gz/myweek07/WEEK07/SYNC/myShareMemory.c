/* 
 * Copyright (C) 2021 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This program is free script/software. This program is distributed in the 
 * hope that it will be useful, but WITHOUT ANY WARRANTY; without even the 
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# INFO: makeMyShareMemory.c
 * REV05: Fri 29 Oct 2021 12:45:22 WIB
 * REV04: Thu 28 Oct 2021 11:23:44 WIB
 * REV03: Mon 25 Oct 2021 06:41:13 WIB
 * REV02: Sat 23 Oct 2021 10:15:57 WIB
 * REV01: Thu 21 Oct 2021 10:49:35 WIB
 * START: Sat 03 Apr 2021 06:20:00 WIB
 */

#include "mylib.h"

int main(void) {
    Buf tmpReport[BUFSIZE3];
    Buf  tmpShare[BUFSIZE1];

    sprintf(tmpReport, "ZCZC PID %d PPID %d HOST %s USER %s GROUP %s\n", 
      getpid(), getppid(), getHost(), getUserName(), getGroupName());
    report1(tmpReport); 

    sprintf(tmpShare,  "%s %s\n", getStamp(), getUserName());
    sprintf(tmpReport, "ZCZC STAMP %s",       tmpShare);
    report1(tmpReport); 

    int fd1  = open(FILE3, MYFLAGS, CHMOD1);
    if (fd1<0)                                error(1,"OPEN fd1 FAILED ======");
    if (fchmod(fd1, CHMOD1)<0)                error(1,"DO fchmod fd1 FAILED ======");
    if (ftruncate(fd1, 1+strlen(tmpShare))<0) error(1,"DO ftruncate fd1 FAILED ======");
    String myShare = mmap(NULL, 1+strlen(tmpShare), MYPROTECTION, MYVISIBILITY, fd1, 0);
    if (myShare == MAP_FAILED)                error(1,"MAP_FAILED mmap myShare");
    close(fd1);

    sprintf(tmpReport, "ZCZC SHARE %s %lu\n", FILE3, 1+strlen(tmpShare));
    report1(tmpReport); 

    strcpy (myShare, tmpShare);
    report1("ZCZC SHARE DONE\n");
}

