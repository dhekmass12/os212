/*
 * Copyright (C) 2021-2021 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This program is free script/software. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# INFO: mylib.h
 * REV04 Fri 29 Oct 2021 13:17:35 WIB
 * REV03 Mon 25 Oct 2021 09:28:34 WIB
 * REV02 Sat 23 Oct 2021 16:08:48 WIB
 * REV01 Thu 21 Oct 2021 10:50:40 WIB
 * START Sat 10 Apr 2021 16:11:24 WIB
 */

#include <fcntl.h>
#include <grp.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define BUFSIZE1       128
#define BUFSIZE2       256
#define BUFSIZE3       1024
#define CHMOD1         0600
#define CHMOD2         0660
#define DOSHASUM       "echo %s|sha1sum|tr '[a-z]' '[A-Z]'|cut -c1-8"
#define GETDATE        "date +%s"
#define MYFLAGS        O_CREAT|O_RDWR
#define MYPROTECTION   PROT_READ|PROT_WRITE
#define MYVISIBILITY   MAP_SHARED
#define OS212SIZE      1024
#define RESULT         8

// FILE2 #define REPORT2        "WEEK07-REPORT2.txt"
// FILE3 #define SHAREFILE      "WEEK07-MYSHARE.bin"
// FILE5 #define SHAREALLSYNC   "/home/zzzSHARE/.zzzW07/WEEK07-ALLSYNC.bin"
#define FILE0          "WEEK07-REPORT0.txt"
#define FILE1          "WEEK07-REPORT1.txt"
#define FILE2          "WEEK07-REPORT2.txt"
#define FILE3          "WEEK07-MYSHARE.bin"
#define FILE4          "WEEK07-ERROR.txt"
#define FILE5          "/home/zzzSHARE/.zzzW07/WEEK07-ALLSYNC.bin"

typedef char*          String;
typedef char           Buf;
typedef unsigned long  UL;
typedef struct group*  Group;
typedef struct stat    FStat;
typedef struct {
    Buf lock    [BUFSIZE1];
    Buf allStamp[BUFSIZE1*OS212SIZE];
} memShare;
typedef memShare*      memPtr;

void   error(int errornum, String message);
void   report1(String message);
void   report2(String message);
void   report (String filename, String message);

String getEpoch(void);
String getGroupName(void);
String getHost(void);
String getStamp(void);
String getUserName(void);

