# REV01 Thu 28 Oct 2021 14:10:30 WIB
# START Fri 16 Apr 2021 17:51:05 WIB

REPORT0="WEEK07-REPORT0.txt"
REPORT1="WEEK07-REPORT1.txt"
MYSHARE="WEEK07-MYSHARE.bin"

DIR="SYNC/"

# Delete Old File
rm -f $REPORT0

# Go Inside
cd $DIR

echo "clean all"
make clean

echo "ZCZC R01 pwd $(pwd)"
echo "ZCZC R01 pwd $(pwd)"            >   $REPORT0
 
echo "ZCZC R02 date $(date)"
echo "ZCZC R02 date $(date)"          >>  $REPORT0

echo "ZCZC R03 make..."
echo "ZCZC R03 make"                  >>  $REPORT0
make                                  >>  $REPORT0

echo "ZCZC R04 run ./myShareMemory"
echo "ZCZC R04 run"                   >>  $REPORT0
./myShareMemory                       >>  $REPORT0 

echo "ZCZC R05 hexdump"
hexdump -C $MYSHARE
echo "ZCZC R05 hexdump"               >>  $REPORT0
hexdump -C $MYSHARE                   >>  $REPORT0

echo "ZCZC R06 $(ls -al)"
echo "ZCZC R06 $(ls -al)"             >>  $REPORT0

echo "ZCZC R07 pwd $(pwd)"
echo "ZCZC R07 pwd $(pwd)"            >>  $REPORT0

echo "ZCZC R08 date $(date)"
echo "ZCZC R08 date $(date)"          >>  $REPORT0

echo "ZCZC R09 mv $REPORT1   ../../"  >> $REPORT0
mv   $REPORT1                ../../
echo "ZCZC R10 mv $MYSHARE   ../../"  >> $REPORT0
mv   $MYSHARE                ../../
echo "ZCZC R11 mv $REPORT0   ../../"  >> $REPORT0
mv   $REPORT0                ../../

echo "clean all"
make clean

exit
exit

