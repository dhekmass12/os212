# REV03 Sun 10 Oct 2021 08:34:30 WIB
# REV02 Sun 03 Oct 2021 17:01:05 WIB
# START Fri 26 Mar 2021 23:46:34 WIB

RESULT="WEEK06-FORK.txt"
DIR="FORK/"

# Delete Old File
rm -f ../$RESULT

# Go Inside
cd $DIR

echo "clean all"
make clean

echo "compile all"
make

echo "ZCZC pwd  $(pwd)"            >  ../../$RESULT
echo "ZCZC date $(date)"           >> ../../$RESULT
echo "ZCZC fork1"                  >> ../../$RESULT
./fork1                            >> ../../$RESULT
sleep 1
echo "ZCZC fork2"                  >> ../../$RESULT
./fork2                            >> ../../$RESULT
echo "ZCZC lsal $(ls -al)"         >> ../../$RESULT
echo "ZCZC move WEEK06-SHARE.bin"  >> ../../$RESULT
mv WEEK06-SHARE.bin                ../../
echo "ZCZC clean $(make clean)"    >> ../../$RESULT
echo "READ $RESULT"

exit
exit

