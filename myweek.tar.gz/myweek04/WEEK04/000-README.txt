# REV01 Sun 26 Sep 2021 14:03:13 WIB
# START Thu 18 Mar 06:13:06 WIB 2021

# Read tlpi-dist/README
# Read tlpi-dist/BUILDING

RESULT="/tmp/WEEK04-TLPI.txt"
DIR="tlpi-dist/"

fecho(){
    echo "ZCZC $1" | tee -a $RESULT
}

expt() {
   local EXSTAMP=$(printf "%8.8X" $(( $(date +%s) & 16#FFFFFFFF )) )
   local EXCHSUM="XXXXXXXX"
   [ "$(hostname)" = "$USER" ] && {
       EXCHSUM=$(echo "$USER$EXSTAMP"|sha1sum|tr '[a-z]' '[A-Z]'| cut -c1-8)
   }
   fecho "expt $EXSTAMP $EXCHSUM"
   fecho "date $(date '+%y%m%d %H%M')"
   fecho "user $USER hostname $(hostname)"
}

# Delete Old File
rm -f $RESULT

expt

# Go Inside
cd $DIR

# clean all
make clean

# compile all
make

fecho "pwd $(pwd)"
expt
fecho "DIRSIZE $(ls -alR|wc -l)"
fecho "FILE1 $(ls -la README)"
fecho "FILE2 $(ls -la time/calendar_time.c)"
fecho "FILE3 $(ls -la time/calendar_time)"
fecho "calendar_time $(time/calendar_time)"
fecho "make clean"
make  clean
sleep 1
expt
fecho "mv RESULT $(mv $RESULT ../../)"
exit
exit
