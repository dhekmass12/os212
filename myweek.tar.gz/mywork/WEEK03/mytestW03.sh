REPORT="reportW03.txt"
expt() {
   local EXSTAMP=$(printf "%8.8X" $(( $(date +%s) & 16#FFFFFFFF )) )
   local EXCHSUM="XXXXXXXX"
   [ "$(hostname)" = "$USER" ] && {
       EXCHSUM=$(echo "$USER$EXSTAMP"|sha1sum|tr '[a-z]' '[A-Z]'| cut -c1-8)
   }
   echo  ZCZC $EXSTAMP $EXCHSUM
}
echo "This is a write test by $USER"               > /$USER/$USER.txt
echo "================================="           > $REPORT
expt                                              >> $REPORT
echo "ZCZC date $(date '+%y%m%d %H%M')"           >> $REPORT
echo "ZCZC user $USER $(hostname)    "            >> $REPORT
echo "ZCZC disk $(cat /proc/mounts | grep $USER)" >> $REPORT
echo "ZCZC ls   $(ls -alR /$USER/$USER.txt)"      >> $REPORT
echo "ZCZC cat  $(cat /$USER/$USER.txt)"          >> $REPORT
echo "ZCZC sleep 2 seconds"                       >> $REPORT
sleep 2;
expt                                              >> $REPORT
echo "================================="          >> $REPORT
